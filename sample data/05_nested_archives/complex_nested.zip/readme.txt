This folder contains both regular files and a protected archive.
