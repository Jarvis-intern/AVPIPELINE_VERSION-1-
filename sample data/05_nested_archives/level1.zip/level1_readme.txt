Level 1 - This is the outer archive containing nested archives.
